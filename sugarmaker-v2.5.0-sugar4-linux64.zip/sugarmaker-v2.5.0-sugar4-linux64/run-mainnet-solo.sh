./sugarmaker -a YespowerSugar -o http://127.0.0.1:34229 -u RPCUSER -p RPCPASSWORD --coinbase-addr=sugar1q49dwwrwxle07wzvs84qe77m6wwfmtkn07ycmcm -t1
