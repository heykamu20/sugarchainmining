./sugarmaker -a YespowerSugar -o http://127.0.0.1:44229 -u RPCUSER -p RPCPASSWORD --coinbase-addr=tugar1qkvl32hmzvgtwpu7v70k5u0kcv9s4uqy4twjge8 -t1
